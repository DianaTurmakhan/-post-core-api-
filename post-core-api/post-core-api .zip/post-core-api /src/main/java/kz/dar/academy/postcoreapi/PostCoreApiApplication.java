package kz.dar.academy.postcoreapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostCoreApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostCoreApiApplication.class, args);
	}

}
