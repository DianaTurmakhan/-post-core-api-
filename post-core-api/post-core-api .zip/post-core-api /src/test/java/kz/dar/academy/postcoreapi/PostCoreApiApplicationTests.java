package kz.dar.academy.postcoreapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostCoreApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
